import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {

    public static void main(String[] args) throws SQLException {


        Lab_3Form frame = new Lab_3Form();
        frame.setVisible(true);

    }
}
