public interface Bookable {

   // String getAuthor();

}
