
public class Main {
    public static void main(String[] args) {
        NewJFrame frame = new NewJFrame();
        frame.setVisible(true);


    }
}
