public interface TextBook extends Bookable {


}
