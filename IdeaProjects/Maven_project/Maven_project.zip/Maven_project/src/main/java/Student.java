public class Student extends Person{

    public  Student(String name, String second_name, String third_name){
        this.name = name;
        this.second_name= second_name;
        this.third_name = third_name;
    }
}
