public class Professor extends Person {
    public Professor(String name, String second_name, String middle_name){
        this.name = name;
        this.second_name = name;
        this.third_name = name;
    }
}
