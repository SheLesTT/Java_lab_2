public interface BookFactory {
    // create textbooks and fiction

    Book createTextbook();
    Fiction createFiction();
}
