public interface GenerateBookData {



    public String createFictionAuthor();
    public String createFictionTitle();

}
