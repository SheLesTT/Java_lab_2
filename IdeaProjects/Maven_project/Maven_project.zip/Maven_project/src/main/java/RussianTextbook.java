
public class RussianTextbook extends Book implements TextBook {

    public RussianTextbook(String author, String title){
        this.title = title;
        this.author = author;

    }



}
