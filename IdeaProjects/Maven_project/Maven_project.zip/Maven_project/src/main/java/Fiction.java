public interface Fiction extends Bookable {
    void generate_info();
}
